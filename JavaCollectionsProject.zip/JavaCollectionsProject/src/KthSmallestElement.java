package javacollections;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


/**
* Program to find the kth smallest element in an ArrayList
*/
public class KthSmallestElement {
public static void main(String[] args) {
ArrayList<Integer> numbers = new ArrayList<>();
numbers.add(5);
numbers.add(3);
numbers.add(8);
numbers.add(1);
numbers.add(7);


int k;
Scanner sc = new Scanner(System.in);
System.out.print("Enter k: ");
k = sc.nextInt();


// Sort the ArrayList
Collections.sort(numbers);
if(k >= 1 && k <= numbers.size()) {
System.out.println(k + "th smallest element: " + numbers.get(k-1));
} else {
System.out.println("Invalid k");
}
sc.close();
}
}