package javacollections;


import java.util.Map;
import java.util.TreeMap;


/**
* TreeMap to store student ID -> details mapping
*/
class Student {
String name;
int age;


Student(String name, int age){
this.name = name;
this.age = age;
}


@Override
public String toString(){
return "Name: " + name + ", Age: " + age;
}
}


public class StudentTreeMap {
public static void main(String[] args){
TreeMap<Integer, Student> students = new TreeMap<>();
students.put(101, new Student("Ali", 20));
students.put(102, new Student("Sara", 22));
students.put(103, new Student("Rafi", 21));


for(Map.Entry<Integer, Student> entry : students.entrySet()){
System.out.println("ID: " + entry.getKey() + " -> " + entry.getValue());
}
}
}