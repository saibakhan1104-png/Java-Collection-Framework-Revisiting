package javacollections;


import java.util.HashMap;
import java.util.Map;


/**
* HashMap to store employee ID -> department mapping
*/
public class EmployeeHashMap {
public static void main(String[] args){
HashMap<Integer, String> empDept = new HashMap<>();
empDept.put(1001, "CSE");
empDept.put(1002, "ICT");
empDept.put(1003, "ME");


for(Map.Entry<Integer, String> entry : empDept.entrySet()){
System.out.println("Employee ID: " + entry.getKey() + " -> Department: " + entry.getValue());
}
}
}