package javacollections;


import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;


/**
* Program to store word frequencies using TreeMap
*/
public class WordFrequencyTreeMap {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.print("Enter a text: ");
String text = sc.nextLine();
sc.close();


String[] words = text.split("\\s+");
TreeMap<String, Integer> freqMap = new TreeMap<>();


for(String word : words) {
word = word.toLowerCase();
freqMap.put(word, freqMap.getOrDefault(word, 0) + 1);
}


// Print word frequencies
for(Map.Entry<String, Integer> entry : freqMap.entrySet()) {
System.out.println(entry.getKey() + " : " + entry.getValue());
}
}
}