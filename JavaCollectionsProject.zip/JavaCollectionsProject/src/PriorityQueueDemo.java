package javacollections;


import java.util.Comparator;
import java.util.PriorityQueue;


/**
* Demonstrate Queue and Stack using PriorityQueue with custom comparator
*/
public class PriorityQueueDemo {
public static void main(String[] args) {
// Min-Heap (Queue behavior)
PriorityQueue<Integer> queue = new PriorityQueue<>();
queue.add(5); queue.add(2); queue.add(8);
System.out.println("Queue (min-heap): " + queue);
System.out.println("Poll: " + queue.poll());


// Max-Heap (Stack behavior using reverse comparator)
PriorityQueue<Integer> stack = new PriorityQueue<>(Comparator.reverseOrder());
stack.add(5); stack.add(2); stack.add(8);
System.out.println("Stack (max-heap): " + stack);
System.out.println("Poll: " + stack.poll());
}
}